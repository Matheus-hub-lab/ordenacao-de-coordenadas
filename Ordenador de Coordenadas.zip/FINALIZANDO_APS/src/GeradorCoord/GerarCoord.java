//Pacote;
package GeradorCoord;

//Bibliotecas;
import java.util.Arrays;
import java.util.Random;
import javax.swing.JOptionPane;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;

//Classe Gerar coordenadas;
public class  GerarCoord {
    
    //Construtor Rando e variaveis privadas;
    Random Coordenada = new Random();
    private double X1 = 2.4572345;
    private double X2 = -7.5847395;
    private double Y1 = -17.1169435;
    private double Y2 = -51.9715955;
    
    //Método Gerar coordenadas;
    public long[] GerarCoordenada(int Quantidade) throws IOException{   
        
        //Variáveis necessárias;
        double latitude;
        double longitude;
        DecimalFormat deci = new DecimalFormat("0.00000");
        double EixoX = 0;
        double EixoY = 0;
        double inicio = 3.0;
        double fim = 4.0;
        double zero = 0.0;
        long coordenada []= new long [Quantidade];
        String coordstring;
        
        //Laço para gerar as coordenadas e colocar elas no arquivo;
        for (int i=0; i<Quantidade; i++){
            try{
                
                //Criação ou busca de arquivo;
                FileWriter arquivo;
                arquivo = new FileWriter(new File("src/file/Arquivo.txt"));
                
                double lati = Coordenada.nextDouble();//eixo X
                EixoX = (X1 + (lati * (X2 - X1)));
                latitude = EixoX;
                double longi = Coordenada.nextDouble();// eixo Y
                EixoY = (Y1 + (longi * (Y2 - Y1)));    
                longitude = EixoY;
                
                //Estrututa da localização;
                coordstring = inicio + deci.format(latitude) + fim + deci.format(longitude);
                
                //Substituição de outros simbolos;
                coordstring = coordstring.replaceAll("\\.","");
                coordstring = coordstring.replaceAll("-","");
                coordstring = coordstring.replaceAll(",","");
                
                //Fechamento do arquivo;
                arquivo.close();
                long coordlong = Long.parseLong(coordstring);
                
                //Localização;
                coordenada[i]= coordlong;
                
                //Tratamento de erro;
            }catch(NumberFormatException e){
            }
        }  
        //Retorno das coordenadas;
        return coordenada;
    }
}
  