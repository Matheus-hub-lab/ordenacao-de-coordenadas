//Pacote;
package GeradorCoord;

//Bibliotecas usadas;
import GeradorCoord.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Random;
import java.util.Scanner;

//Classe programa;
public class Programa {

    //Método Principal(main)/
    public static void main(String[] args) {
        Scanner opc = new Scanner(System.in);
        boolean Menu = true;
        
        //Menu principal;
        while(Menu == true){
            
            //Tratamento de erro caso o usuário não digite um número inteiro positivo maior que 0; 
            try{
                System.out.println("\n");
                System.out.println("******************************");
                System.out.println("PROGRAMA DE ORDENAÇÃO DE DADOS");
                System.out.println("******************************");
                System.out.println("MENU");
                System.out.println("1-Gerar e gravar coordenadas");
                System.out.println("2-Ler Arquivo");
                System.out.println("3-Apagar Arquivo");
                System.out.println("4-Sair");
                System.out.println("Opção: ");
                int opcao = Integer.parseInt(opc.nextLine());
                System.out.println("\n");
                
                //Verifica se o numero digitato é negativo; 
                if (opcao < 0) {
                       System.out.println("O número deve ser inteiro, positivo e maior que 0!");
                }
                
                //Caso escolha o item 1;
                else if(opcao == 1){
                    
                    //Contrutores necessários para gerar as coordenadas e ler os dados que o usuário vai inserir;
                    GerarCoord gc = new GerarCoord();
                    Scanner quant = new Scanner(System.in);
                    
                    //Tratamento de erro caso o usuário não digite um número inteiro positivo maior que 0; 
                    try{
                        System.out.println("EX 1: 10.000");
                        System.out.println("EX 2: 100.000");
                        System.out.println("EX 3: 1.000.000");
                        //Definição de quantidades de coordenadas;
                        System.out.println("Quantas coordenadas?");
                        double a = Integer.parseInt(opc.nextLine());

                        //Verifica se o numero digitado é negativo; 
                        if (a <= 0) {
                            System.out.println("O número deve ser inteiro, positivo e maior que 0!");
                            break;
                        }
                   
                        System.out.println("\n");


                        long Latitude[];
                        int um = 1;
                        int b =0;
                        int x ;
                        x = (int) a;
                        
                        if(a==10000){
                                                            
                                //Tratamento de erro caso o arquivo não exista;
                                try {

                                    //Busca ou criação de arquivo;
                                    FileWriter arquivo;

                                    arquivo = new FileWriter(new File("src/file/10000.txt"));

                                    //Coordenadas não ordenadas
                                    arquivo.write("---------------------------------\n");
                                    arquivo.write("Coordenadas:\n");
                                    //long tempoInicial = System.currentTimeMillis();
                                    Latitude = gc.GerarCoordenada(x);
                                    //System.out.println("Tempo de Geraçao de coordenada " + ((System.currentTimeMillis() - tempoInicial)/1000)
                                      //      + "segundos\n");
                                    System.out.println("Coordenadas feitas e gravadas no arquivo TXT\n");

                                    //Inserção de dados no arquivo TXT;
                                    for(int i=0;i<x;i++){
                                        arquivo.write(String.valueOf(Latitude[i]));
                                        arquivo.write("\n");
                                    }

                                    String resultadoLatitude = "";
                                    
                                    //chamendo o método de ordenamento;
                                    quickSort(Latitude,0,Latitude.length-1);
                                    //selectionSort(Latitude);
                                    //Vetor necessário para a ordenação;
                                    //long w[] = new long[Latitude.length];
                                    //mergeSort(Latitude,w,0,Latitude.length-1);      
                                    
                                    //Coordenadas ordenadas;
                                    arquivo.write("---------------------------------\n");
                                    arquivo.write("Coordenadas ordenadas:\n");
                                    long tempoSelection = System.currentTimeMillis();

                                    //Chamando algoritmo de ordenação;
                                    

                                    //Tempo de ordenação;
                                    System.out.println("Tempo de ordenação SelectionSort " + (System.currentTimeMillis() - tempoSelection)
                                            + "Milesimos\n");

                                    //Inserção de dados no arquivo TXT;
                                    for(int i=0;i<x;i++){
                                        arquivo.write(String.valueOf(Latitude[i]));
                                        arquivo.write("\n");
                                    }

                                    //Fechamento do arquivo;
                                    arquivo.close();

                                    //verifica se arquivo está ocupado;
                                    if(arquivo != null){
                                        System.out.println("Arquivo Ocupado\n");

                                    }  

                                //Tratamento de erro;
                                } catch (IOException e) {
                                    System.out.printf("Erro na abertura do arquivo: Arquivo não existe ou arquivo ocupado!!\n");
                                } 
                                break;
                        }
                        if(a==100000){
                                                            //Tratamento de erro caso o arquivo não exista;
                                try {

                                    //Busca ou criação de arquivo;
                                    FileWriter arquivo;

                                    arquivo = new FileWriter(new File("src/file/100000.txt"));

                                    //Coordenadas não ordenadas
                                    arquivo.write("---------------------------------\n");
                                    arquivo.write("Coordenadas:\n");
                                    //long tempoInicial = System.currentTimeMillis();
                                    Latitude = gc.GerarCoordenada(x);
                                    //System.out.println("Tempo de Geraçao de coordenada " + ((System.currentTimeMillis() - tempoInicial)/1000)
                                      //      + "segundos\n");
                                    System.out.println("Coordenadas feitas e gravadas no arquivo TXT\n");

                                    //Inserção de dados no arquivo TXT;
                                    for(int i=0;i<x;i++){
                                        arquivo.write(String.valueOf(Latitude[i]));
                                        arquivo.write("\n");
                                    }

                                    String resultadoLatitude = "";
                                    
                                    //chamendo o método de ordenamento;
                                    quickSort(Latitude,0,Latitude.length-1);
                                    //selectionSort(Latitude);
                                    //Vetor necessário para a ordenação;
                                    //long w[] = new long[Latitude.length];
                                    //mergeSort(Latitude,w,0,Latitude.length-1);      
                                    
                                    //Coordenadas ordenadas;
                                    arquivo.write("---------------------------------\n");
                                    arquivo.write("Coordenadas ordenadas:\n");
                                    long tempoSelection = System.currentTimeMillis();

                                    //Chamando algoritmo de ordenação;
                                    selectionSort(Latitude);

                                    //Tempo de ordenação;
                                    System.out.println("Tempo de ordenação SelectionSort " + (System.currentTimeMillis() - tempoSelection)
                                            + "Milesimos\n");

                                    //Inserção de dados no arquivo TXT;
                                    for(int i=0;i<x;i++){
                                        arquivo.write(String.valueOf(Latitude[i]));
                                        arquivo.write("\n");
                                    }

                                    //Fechamento do arquivo;
                                    arquivo.close();

                                    //verifica se arquivo está ocupado;
                                    if(arquivo != null){
                                        System.out.println("Arquivo Ocupado\n");

                                    }  

                                //Tratamento de erro;
                                } catch (IOException e) {
                                    System.out.printf("Erro na abertura do arquivo: Arquivo não existe ou arquivo ocupado!!\n");
                                } 
                                break;
                        }
                        if(a==1000000){
                                //Tratamento de erro caso o arquivo não exista;
                                try {

                                    //Busca ou criação de arquivo;
                                    FileWriter arquivo;

                                    arquivo = new FileWriter(new File("src/file/1000000.txt"));

                                    //Coordenadas não ordenadas
                                    arquivo.write("---------------------------------\n");
                                    arquivo.write("Coordenadas:\n");
                                    //long tempoInicial = System.currentTimeMillis();
                                    Latitude = gc.GerarCoordenada(x);
                                    //System.out.println("Tempo de Geraçao de coordenada " + ((System.currentTimeMillis() - tempoInicial)/1000)
                                      //      + "segundos\n");
                                    System.out.println("Coordenadas feitas e gravadas no arquivo TXT\n");

                                    //Inserção de dados no arquivo TXT;
                                    for(int i=0;i<x;i++){
                                        arquivo.write(String.valueOf(Latitude[i]));
                                        arquivo.write("\n");
                                    }

                                    String resultadoLatitude = "";
                                    
                                    //chamendo o método de ordenamento;
                                    quickSort(Latitude,0,Latitude.length-1);
                                    //selectionSort(Latitude);
                                    //Vetor necessário para a ordenação;
                                    //long w[] = new long[Latitude.length];
                                    //mergeSort(Latitude,w,0,Latitude.length-1);      
                                    
                                    //Coordenadas ordenadas;
                                    arquivo.write("---------------------------------\n");
                                    arquivo.write("Coordenadas ordenadas:\n");
                                    long tempoSelection = System.currentTimeMillis();

                                    //Chamando algoritmo de ordenação;
                                    selectionSort(Latitude);

                                    //Tempo de ordenação;
                                    System.out.println("Tempo de ordenação SelectionSort " + (System.currentTimeMillis() - tempoSelection)
                                            + "Milesimos\n");

                                    //Inserção de dados no arquivo TXT;
                                    for(int i=0;i<x;i++){
                                        arquivo.write(String.valueOf(Latitude[i]));
                                        arquivo.write("\n");
                                    }

                                    //Fechamento do arquivo;
                                    arquivo.close();

                                    //verifica se arquivo está ocupado;
                                    if(arquivo != null){
                                        System.out.println("Arquivo Ocupado\n");

                                    }  

                                //Tratamento de erro;
                                } catch (IOException e) {
                                    System.out.printf("Erro na abertura do arquivo: Arquivo não existe ou arquivo ocupado!!\n");
                                } 
                                break;
                        }

                        //Menu secundário (Definir método de ordenação);
                        System.out.println("Qual método escolher?");
                        System.out.println("1-Selection Sort");
                        System.out.println("2-Merge Sort");
                        System.out.println("3-Quick Sort");
                        System.out.println("Escolha pelo numero: ");

                        int c = Integer.parseInt(opc.nextLine());
                        System.out.println("\n");
                        
                        //Verifica se o numero digitado é negativo;
                        if (c < 0) {
                            System.out.println("O número deve ser inteiro, positivo e maior que 0!");
                            
                        }
                        
                        //Método de ordenação: Selection Sort;
                            if(c==1){
                                
                                //Tratamento de erro caso o arquivo não exista;
                                try {

                                    //Busca ou criação de arquivo;
                                    FileWriter arquivo;

                                    arquivo = new FileWriter(new File("src/file/Arquivo.txt"));

                                    //Coordenadas não ordenadas
                                    arquivo.write("---------------------------------\n");
                                    arquivo.write("Coordenadas:\n");
                                    //long tempoInicial = System.currentTimeMillis();
                                    Latitude = gc.GerarCoordenada(x);
                                    //System.out.println("Tempo de Geraçao de coordenada " + ((System.currentTimeMillis() - tempoInicial)/1000)
                                      //      + "segundos\n");
                                    System.out.println("Coordenadas feitas e gravadas no arquivo TXT\n");

                                    //Inserção de dados no arquivo TXT;
                                    for(int i=0;i<x;i++){
                                        arquivo.write(String.valueOf(Latitude[i]));
                                        arquivo.write("\n");
                                    }

                                    String resultadoLatitude = "";

                                    //Coordenadas ordenadas;
                                    arquivo.write("---------------------------------\n");
                                    arquivo.write("Coordenadas ordenadas:\n");
                                    long tempoSelection = System.currentTimeMillis();

                                    //Chamando algoritmo de ordenação;
                                    selectionSort(Latitude);

                                    //Tempo de ordenação;
                                    System.out.println("Tempo de ordenação SelectionSort " + (System.currentTimeMillis() - tempoSelection)
                                            + "Milesimos\n");

                                    //Inserção de dados no arquivo TXT;
                                    for(int i=0;i<x;i++){
                                        arquivo.write(String.valueOf(Latitude[i]));
                                        arquivo.write("\n");
                                    }

                                    //Fechamento do arquivo;
                                    arquivo.close();

                                    //verifica se arquivo está ocupado;
                                    if(arquivo != null){
                                        System.out.println("Arquivo Ocupado\n");

                                    }  

                                //Tratamento de erro;
                                } catch (IOException e) {
                                    System.out.printf("Erro na abertura do arquivo: Arquivo não existe ou arquivo ocupado!!\n");
                                } 


                            //Método de ordenação: Merge Sort;
                            } else if(c==2){
                                
                                //Tratamento de erro caso o arquivo não exista;
                                try {

                                    //Busca ou criação de arquivo TXT;
                                    FileWriter arquivo;
                                    arquivo = new FileWriter(new File("src/file/Arquivo.txt"));

                                    //Coordenadas não ordenadas;
                                    arquivo.write("---------------------------------\n");
                                    arquivo.write("Coordenadas:\n");
                                    //long tempoInicial = System.currentTimeMillis();

                                    //Gerando coordenadas;
                                    Latitude = gc.GerarCoordenada(x);
                                    //System.out.println("Tempo de Geraçao de coordenada " + ((System.currentTimeMillis() - tempoInicial)/1000)
                                     //       + "segundos\n");

                                    System.out.println("Coordenadas feitas e gravadas no arquivo TXT\n");

                                    String resultadoLatitude = "";

                                    //Inserção de dados no arquivo TXT;
                                    for(int i=0;i<x;i++){
                                        arquivo.write(String.valueOf(Latitude[i]));
                                        arquivo.write("\n");
                                    }

                                    //Vetor necessário para a ordenação;
                                    long w[] = new long[Latitude.length];

                                    long tempoMargeSort = System.currentTimeMillis();

                                    //Algoritmo de ordenação;
                                    mergeSort(Latitude,w,0,Latitude.length-1);

                                    //Tempo de ordenação;
                                    System.out.println("Tempo de ordenação MergeSort " + (System.currentTimeMillis() - tempoMargeSort)
                                            + "Milesimos\n");

                                    //Coordenadas ordenadas;
                                    arquivo.write("---------------------------------\n");
                                    arquivo.write("Coordenadas ordenadas:\n");

                                     //Inserção de dados ordenados no arquivo TXT
                                    for(int i=0;i<x;i++){
                                        arquivo.write(String.valueOf(Latitude[i]));
                                        arquivo.write("\n");
                                    }

                                    //Verifica se arquivo esta ocupado;
                                    if(arquivo != null){
                                        System.out.println("Arquivo Ocupado\n");

                                    }  
                                     //Tratamento de erro;
                                } catch (IOException e) {
                                    System.out.printf("Erro na abertura do arquivo: Arquivo não existe ou arquivo ocupado!!\n");
                                } 

                            } else if(c==3){
                                
                                //Tratamento de erro caso o arquivo não exista;
                                try {

                                    //Busca ou criação de arquivo TXT;
                                    FileWriter arquivo;
                                    arquivo = new FileWriter(new File("src/file/Arquivo.txt"));

                                    //Coordenadas não ordenadas;
                                    arquivo.write("---------------------------------\n");
                                    arquivo.write("Coordenadas:\n");
                                    //long tempoInicial = System.currentTimeMillis();

                                    //Gerar coordenadas;
                                    Latitude = gc.GerarCoordenada(x);

                                    //System.out.println("Tempo de Geraçao de coordenada " + ((System.currentTimeMillis() - tempoInicial)/1000)
                                      //      + "segundos\n");
                                    System.out.println("Coordenaddas feitas e gravadas no arquivo TXT\n");
                                    String resultadoLatitude = "";

                                    //Inserção de dados não ordenados no arquivo TXT
                                    for(int i=0;i<x;i++){
                                        arquivo.write(String.valueOf(Latitude[i]));
                                        arquivo.write("\n");
                                    }

                                    long tempoQuickSort = System.currentTimeMillis();

                                    //Algoritmo de ordenação Quick Sort;
                                    quickSort(Latitude,0,Latitude.length-1);

                                    //Tempo de ordenação;
                                    System.out.println("Tempo de ordenação QuickSort " + (System.currentTimeMillis() - tempoQuickSort)
                                             + "Milesimos\n");

                                    //Coordenadas ordenadas;
                                    arquivo.write("---------------------------------\n");
                                    arquivo.write("Coordenadas ordenadas:\n");

                                    //Inserção de dados ordenados no arquivo TXT;
                                    for(int i=0;i<x;i++){
                                        arquivo.write(String.valueOf(Latitude[i]));
                                        arquivo.write("\n");
                                    }

                                    //Verifica se o arquivo esta ocupado;
                                    if(arquivo != null){
                                        System.out.println("Arquivo Ocupado\n");

                                    }  

                                    //Fechamento de arquivo;
                                    arquivo.close();

                                //Tratamento de erro;
                                } catch (IOException e) {
                                    System.out.printf("Erro na abertura do arquivo: Arquivo não existe ou arquivo ocupado!!\n");
                                } 
                            }
                        //Tratamento do erro; 
                        }catch (NumberFormatException e) {
                            System.out.println("Por favor, digite um número inteiro, positivo e maior que 0!");
                        }


                    //Ler arquivo;
                    }else if(opcao==2){

                                    //Busca ou criação do arquivo;
                                    File Arquivo = new File("src/file/Arquivo.txt");
                                    
                                    //Trata o erro caso o arquivo não exista;
                                    try {
                                        
                                        //Construtores necessários para ler o arquivo;
                                        FileReader arq = new FileReader(Arquivo);
                                        BufferedReader lerArq = new BufferedReader(arq);

                                        //Leitura do arquivo;
                                        String linha = lerArq.readLine(); 
                                        while (linha != null) {
                                            System.out.printf("%s\n", linha);
                                            linha = lerArq.readLine(); 
                                        }

                                        //Fechamento do arquivo;
                                        arq.close();

                                    //Tratamento de erro;
                                    } catch (IOException e) {
                                        System.out.printf("Erro na abertura do arquivo: Arquivo não existe ou arquivo ocupado!!\n");
                                    }

                    //Deletar arquivo; 
                    }else if(opcao == 3){
                                   File arquivo = new File("src/file/Arquivo.txt");
                                   arquivo.delete();
                                   System.out.print("Arquivo apagado!!\n");

                    //Fechamento do programa;
                    }else if (opcao == 4){
                         System.out.print("Obrigado e volte sempre.\n");
                                    Menu = false;
                    }else{
                        //Mensagem de aviso;
                        System.out.print("Por favor selecionar um menu existente!\n\n");
                    }
            //Trata o erro caso o usuário não digitar um numero inteiro positivo e maior que 0;
            } catch (NumberFormatException e) {
                System.out.println("Por favor, digite um número inteiro, positivo e maio que 0!");
            }
        }
        //Agradecimento;
            System.out.println("Obrigado pelo uso!!\n");
    }
    
        //Método de ordenação: Quick Sort;
        public static void quickSort(long v[], int esquerda, int direita) {
		int esq = esquerda;
		int dir = direita;
		long pivo = v[(esq + dir) / 2];
		long troca;

		while (esq <= dir) {
			while (v[esq] < pivo) {
				esq = esq + 1;
			}
			while (v[dir] > pivo) {
				dir = dir - 1;
			}
			if (esq <= dir) {
				troca = v[esq];
				v[esq] = v[dir];
				v[dir] = troca;
				esq = esq + 1;
				dir = dir - 1;
			}
		}
		if (dir > esquerda)
			quickSort(v, esquerda, dir);

		if (esq < direita)
			quickSort(v, esq, direita);

	}
    
    //Método de ordenação: Merge Sort;
    private static void mergeSort(long[] v, long[] w, int ini, int fim) {
        if(ini<fim){
            int meio = (ini + fim)/2;
            mergeSort(v,w,ini,meio);
            mergeSort(v,w,meio+1,fim);
            for(int k = ini; k<=fim; k++ )
            w[k]=v[k];
            int i = ini;
            int j = meio + 1;
            for(int k = ini; k <= fim; k++){
                if(i>meio)v[k]=w[k];
                else if(j>fim)v[k] = w[i++];
                else if(w[i]<w[j])v[k]=w[i++];
                else v[k]=w[j++];
            }
        }
    }    
    
    
    //Método de ordenação: Selection Sort;
    private static void selectionSort(long[] v) {
       for(int i = 0; i<v.length; i++){
           int menor = i;
           for(int j = i+1; j < v.length; j++ ){
               if(v[j]<v[menor])
                   menor = j;
           }
           long aux = v[i];
           v[i]=v[menor];
           v[menor]=aux;
       } 
    }
  
}




